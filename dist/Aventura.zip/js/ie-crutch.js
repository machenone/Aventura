var e = ("article,aside,figcaption,figure,footer,header,hgroup,nav,section,time").split(','), i;
for (var i = 0; i < e.length; i++) {
    document.createElement(e[i]);
}
